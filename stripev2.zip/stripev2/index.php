<?php
$products = [
    ['id' => 'prod_1', 'name' => 'Broek', 'price' => 1000, 'image' => 'broek.jpg'],
    ['id' => 'prod_2', 'name' => 'T-Shirt', 'price' => 2000, 'image' => 'tshirt.jpg'],
    ['id' => 'prod_3', 'name' => 'Ketting', 'price' => 3000, 'image' => 'ketting.jpg'],
    ['id' => 'prod_4', 'name' => 'Horloge', 'price' => 5500, 'image' => 'horloge.jpg'],
    ['id' => 'prod_5', 'name' => 'Schoenen', 'price' => 6200, 'image' => 'schoenen.jpg'],
    ['id' => 'prod_6', 'name' => 'Riem', 'price' => 8999, 'image' => 'riem.jpg'],
];


?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Productpagina</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<button class="theme-toggle-btn" onclick="toggleTheme()">Thema veranderen</button>

<script src="scripts.js"></script>

    <header>
        <h1>Producten</h1>
    </header>
    <main class="products-container">
        <?php foreach ($products as $product): ?>
            <article class="product-card">
                <img src="images/<?php echo htmlspecialchars($product['image'], ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($product['name'], ENT_QUOTES, 'UTF-8'); ?>" class="product-image">
                <h2><?php echo htmlspecialchars($product['name'], ENT_QUOTES, 'UTF-8'); ?></h2>
                <p>€<?php echo number_format($product['price'] / 100, 2); ?></p>
                <form action="checkout.php" method="POST">
                    <input type="hidden" name="productId" value="<?php echo htmlspecialchars($product['id'], ENT_QUOTES, 'UTF-8'); ?>">
                    <button type="submit" class="buy-button">Kopen</button>
                </form>
            </article>
        <?php endforeach; ?>
    </main>
    <footer>
        <p>&copy; <?php echo date("Y"); ?> mello.</p>
    </footer>
</body>
</html>
