<?php
require 'vendor/autoload.php';


$products = [
    'prod_1' => ['name' => 'Product 1', 'price' => 1000], // Prijs in centen
    'prod_2' => ['name' => 'Product 2', 'price' => 2000],
    'prod_3' => ['name' => 'Product 3', 'price' => 3000],
    'prod_4' => ['name' => 'Product 4', 'price' => 5500],
    'prod_5' => ['name' => 'Product 5', 'price' => 6200],
    'prod_6' => ['name' => 'Product 6', 'price' => 8999],
];


$productId = $_POST['productId'];
$product = $products[$productId];


\Stripe\Stripe::setApiKey('SECRET_KEY_STRIPE');


$session = \Stripe\Checkout\Session::create([
    'payment_method_types' => ['card'],
    'line_items' => [[
        'price_data' => [
            'currency' => 'eur',
            'product_data' => [
                'name' => $product['name'],
            ],
            'unit_amount' => $product['price'],
        ],
        'quantity' => 1,
    ]],
    'mode' => 'payment',
    'success_url' => 'http://jouwwebsite.com/success.php',
    'cancel_url' => 'http://localhost/stripegpt/index.php',
]);

// Redirect de klant naar Stripe Checkout
header("Location: " . $session->url, true, 303);
exit;
